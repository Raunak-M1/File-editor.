package com.raunak.fileeditor

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.zip.ZipFile
import java.io.File
import java.io.FileOutputStream

private val Ink = Color(0xFF090B0E)
private val Panel = Color(0xFF171B20)
private val Muted = Color(0xFF9BA3AD)
private val Accent = Color(0xFFE6E9ED)

class MainActivity : ComponentActivity() {
    private var onPicked: ((Uri) -> Unit)? = null
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { onPicked?.invoke(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(
                background = Ink, surface = Panel, primary = Accent,
                onBackground = Color.White, onSurface = Color.White
            )) {
                FileEditorHome(
                    onPickFile = { callback ->
                        onPicked = callback
                        picker.launch(arrayOf("*/*"))
                    }
                )
            }
        }
    }
}

@Composable
private fun FileEditorHome(onPickFile: ((Uri) -> Unit) -> Unit) {
    var selectedName by remember { mutableStateOf("No file selected") }
    var entries by remember { mutableStateOf<List<String>>(emptyList()) }
    var status by remember { mutableStateOf("Offline mode · No root required") }
    var busy by remember { mutableStateOf(false) }
    val context = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    Box(
        Modifier.fillMaxSize().background(
            Brush.verticalGradient(listOf(Color(0xFF20262D), Ink, Color(0xFF050607)))
        )
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 20.dp)) {
            Spacer(Modifier.height(18.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("FILE EDITOR", color = Color.White, fontSize = 12.sp, letterSpacing = 3.sp)
                    Text("Your files. Your control.", color = Muted, fontSize = 13.sp)
                }
                Surface(shape = RoundedCornerShape(50), color = Color(0x332FFFFFF)) {
                    Text("OFFLINE", Modifier.padding(horizontal = 13.dp, vertical = 8.dp),
                        color = Color(0xFFB9E5C9), fontSize = 10.sp, letterSpacing = 1.5.sp)
                }
            }

            Spacer(Modifier.height(28.dp))
            Text("Workspace", color = Color.White, fontSize = 30.sp, fontWeight = FontWeight.SemiBold)
            Text("Explore and inspect files on this device.", color = Muted, fontSize = 14.sp)
            Spacer(Modifier.height(22.dp))

            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(color = Color(0x22FFFFFF), shape = RoundedCornerShape(16.dp)) {
                        Icon(Icons.Default.FolderOpen, null, tint = Color.White,
                            modifier = Modifier.padding(14.dp).size(27.dp))
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("File explorer", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Choose files using Android's system picker", color = Muted, fontSize = 12.sp)
                    }
                    Icon(Icons.Default.ArrowForward, null, tint = Muted)
                }
                Spacer(Modifier.height(16.dp))
                Button(
                    onClick = { onPickFile { uri ->
                        selectedName = DocumentFile.fromSingleUri(context, uri)?.name ?: "Selected file"
                        status = "Selected: $selectedName"
                        entries = emptyList()
                    } },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE8EAED), contentColor = Ink),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Choose a file")
                }
            }

            Spacer(Modifier.height(14.dp))
            GlassCard {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Android, null, tint = Color.White)
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("APK / ZIP inspector", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("View archive contents without modifying the original", color = Muted, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(selectedName, color = Color(0xFFD8DDE3), fontSize = 13.sp)
                Spacer(Modifier.height(10.dp))
                OutlinedButton(
                    enabled = selectedName != "No file selected" && !busy,
                    onClick = {
                        onPickFile { uri ->
                            selectedName = DocumentFile.fromSingleUri(context, uri)?.name ?: "Selected file"
                            busy = true
                            scope.launch {
                                val result = withContext(Dispatchers.IO) {
                                    runCatching {
                                        val temp = File(context.cacheDir, "inspect_${System.currentTimeMillis()}.zip")
                                        context.contentResolver.openInputStream(uri)!!.use { input ->
                                            FileOutputStream(temp).use { output -> input.copyTo(output) }
                                        }
                                        val names = mutableListOf<String>()
                                        ZipFile(temp).use { zip ->
                                            val enumeration = zip.entries()
                                            while (enumeration.hasMoreElements() && names.size < 300) {
                                                names += enumeration.nextElement().name
                                            }
                                        }
                                        temp.delete()
                                        names
                                    }.getOrElse { listOf("Unable to read archive: ${it.message}") }
                                }
                                entries = result
                                status = if (result.isEmpty()) "No archive entries found" else "${result.size} entries shown (maximum 300)"
                                busy = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White)
                ) {
                    if (busy) CircularProgressIndicator(Modifier.size(17.dp), strokeWidth = 2.dp)
                    else Icon(Icons.Default.Visibility, null)
                    Spacer(Modifier.width(8.dp))
                    Text("Inspect APK / ZIP")
                }
            }

            Spacer(Modifier.height(14.dp))
            GlassCard(Modifier.weight(1f, fill = false)) {
                Text("Contents", color = Color.White, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(8.dp))
                if (entries.isEmpty()) {
                    Text("Select an APK or ZIP, then inspect it.", color = Muted, fontSize = 13.sp)
                } else {
                    LazyColumn(Modifier.heightIn(max = 250.dp)) {
                        items(entries) { item ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 7.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Icon(if (item.endsWith("/")) Icons.Default.Folder else Icons.Default.Description,
                                    null, tint = Muted, modifier = Modifier.size(17.dp))
                                Spacer(Modifier.width(9.dp))
                                Text(item, color = Color(0xFFD7DCE2), fontSize = 12.sp)
                            }
                            HorizontalDivider(color = Color(0x22FFFFFF))
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Text(status, color = Muted, fontSize = 11.sp, modifier = Modifier.padding(bottom = 12.dp))
        }
    }
}

@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier.fillMaxWidth()
            .background(
                Brush.linearGradient(listOf(Color(0x44FFFFFF), Color(0x12FFFFFF))),
                RoundedCornerShape(22.dp)
            )
            .border(1.dp, Color(0x30FFFFFF), RoundedCornerShape(22.dp))
            .padding(17.dp),
        content = content
    )
}
